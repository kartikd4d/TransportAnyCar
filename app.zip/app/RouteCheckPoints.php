<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RouteCheckPoints extends Model
{
    protected $guarded = [];
}
