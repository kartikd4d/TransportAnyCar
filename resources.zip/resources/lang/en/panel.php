<?php

return [
    'lbl_login' => 'Login',
];
