<tr>
    <td style="padding: 25px 45px 5px; font-family: arial; font-size: 14px; color: #333; line-height: normal;"
        width="550">Thank you,
    </td>
</tr>
<tr>
    <td style="padding: 0 45px 50px; font-family: arial; font-size: 14px; font-weight: bold; color: #000; line-height: normal;"
        width="550">The {{site_name}}Team
    </td>
</tr>
<tr>
    <td align="center"
        style="padding:20px 45px; font-family: arial; background:#4E0DA1;color: #fff; font-size:15px; margin:0;"
        width="550">Transport Any Car</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</body>
</html>
