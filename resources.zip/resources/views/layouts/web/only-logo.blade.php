<header class="header">
    <div class="container">
        <nav class="navbar">
            <a class="brand" href="{{route('front.home')}}">
                <img src="{{site_logo}}" alt="brand_logo" />
            </a>
        </nav>
    </div>
</header>
